CREATE VIEW CLASS
AS
SELECT CourseName,CourseType,StudentLevel,Name,Title,Qualification FROM COURSE,TEACHER
WHERE Lecturer = Name;
GO
