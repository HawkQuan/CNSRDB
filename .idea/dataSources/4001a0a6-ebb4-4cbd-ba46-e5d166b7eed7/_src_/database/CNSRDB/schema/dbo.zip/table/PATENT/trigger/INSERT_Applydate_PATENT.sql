CREATE TRIGGER INSERT_Applydate_PATENT ON PATENT
INSTEAD OF INSERT
AS
BEGIN
DECLARE @date datetime
SELECT  @date = Applydate FROM inserted
IF @date<='2017-11-22' 
	INSERT INTO PATENT
		SELECT Num,Applicant,InventionName,Author,State,Applydate,Opendate
		FROM inserted
ELSE
	INSERT INTO PATENTERROR
		SELECT Num,Applicant,InventionName,Author,State,Applydate,Opendate,GETDATE()
		FROM inserted
END
GO
