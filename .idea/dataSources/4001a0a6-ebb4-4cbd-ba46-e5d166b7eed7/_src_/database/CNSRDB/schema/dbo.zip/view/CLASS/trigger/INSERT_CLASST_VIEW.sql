CREATE TRIGGER INSERT_CLASST_VIEW ON CLASS
INSTEAD OF INSERT
AS
BEGIN
DECLARE @studentlevel NVARCHAR(50)
DECLARE @coursename NVARCHAR(50)
DECLARE @coursetype NVARCHAR(10)
DECLARE @teachername NVARCHAR(20)
DECLARE @teachertitle NVARCHAR(10)
DECLARE @teacherquali NVARCHAR(20) 
SELECT  @studentlevel = StudentLevel,@coursename=CourseName,@coursetype=CourseType,@teachername=Name,@teachertitle=Title,@teacherquali=Qualification FROM inserted
	INSERT INTO COURSE(CourseName,CourseType,StudentLevel,Lecturer) VALUES(@coursename,@coursetype,@studentlevel,@teachername)
	INSERT INTO TEACHER(Name,Title,Qualification) VALUES(@teachername,@teachertitle,@teacherquali)
END
GO
