CREATE TRIGGER UPDATE_CLASST_VIEW ON CLASS
INSTEAD OF UPDATE
AS
BEGIN
DECLARE @studentlevel NVARCHAR(50)
DECLARE @coursename NVARCHAR(50)
DECLARE @coursetype NVARCHAR(10)
DECLARE @teachername NVARCHAR(20)
DECLARE @teachertitle NVARCHAR(10)
DECLARE @teacherquali NVARCHAR(20)
DECLARE @TID INT
DECLARE @CID INT 
SELECT  @studentlevel = StudentLevel,@coursename=CourseName,@coursetype=CourseType,@teachername=Name,@teachertitle=Title,@teacherquali=Qualification FROM inserted

SELECT TOP(1) @TID=TEACHER.ID,@CID=COURSE.ID FROM TEACHER,COURSE
	WHERE Lecturer=@teachername AND Name=@teachername

	UPDATE COURSE SET CourseName=@coursename,CourseType=@coursetype,StudentLevel=@studentlevel,Lecturer=@teachername WHERE ID=@CID
	UPDATE TEACHER SET Name=@teachername,Title=@teachertitle,Qualification=@teacherquali WHERE ID=@TID
END
GO
