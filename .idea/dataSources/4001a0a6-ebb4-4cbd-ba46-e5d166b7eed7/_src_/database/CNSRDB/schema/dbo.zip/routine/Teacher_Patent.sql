CREATE Procedure Teacher_Patent
@ChName NVARCHAR(20)
AS
SELECT Name,COUNT(InventionName) AS '专利数量（申请/授权）'
FROM TEACHER,PATENT
WHERE Name=@ChName AND Author = Name
GROUP BY Name
GO
